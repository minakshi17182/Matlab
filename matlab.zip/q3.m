R=82;
f=0:10:1000;
L=0.01;
C=10^(-6);
Xc=1./(2*pi.*f*C);
Xl=2.*pi.*f*L;
Z=(R^2+abs(Xl-Xc).^2).^(1/2);
subplot(1,3,1);
plot(f,Z),xlabel('Frequency(f)'),ylabel('Impedance(Z)');
subplot(1,3,2);
plot(f,Xc),xlabel('Frequency(f)'),ylabel('Reactance(Xc)');
subplot(1,3,3);
plot(f,Xl),xlabel('Frequency(f)'),ylabel('Inductance(Xl)');


