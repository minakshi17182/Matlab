f=linspace(20,2000,100);
f0=400;
hfact=(1./1+(f/f0).^6).^(1/2);
subplot(1,2,1)
plot(f,hfact,'b-'),title('Magnitude');

s=(j*f)/f0;
h=1./((1+s).*(1+s+s.^2));
theta=-angle(h)*180/pi;
subplot(1,2,2);
plot(f,theta,'r-'),title('Phase');
