n=0:1:10;
Xn=sin(2*pi*n);
Hn=(n>=0);
An=conv(Xn,20*Hn,'same');

subplot(1,3,1);
plot(n,Xn),xlabel('n'),ylabel('Xn');

subplot(1,3,2);
plot(n,20*Hn),xlabel('n'),ylabel('20*Hn');

subplot(1,3,3);
plot(n,An),xlabel('n'),ylabel('convolution');