
Fs=floor(1000/82);
t=-6:1/Fs:6;
y=sin(2*pi*t);
plot(t,sin(t));
clear all;



