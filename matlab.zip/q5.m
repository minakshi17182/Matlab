t=-40:40;
un=(t-5==0);
stem(t,un);
figure;

us=(t>=0);
stem(t,10*us);
figure;

x=0:100;
f=exp(-82*x);
plot(x,f);

