figure
x=-1*pi:0.01:1*pi;
plot(x,sin(x),x,cos(x)),xlabel('angle'),ylabel('amplitude'),title('sin(x) vs cos(x)'),legend('sinx','cosx');
set(gca,'fontname','Times New Roman','Fontsize',20),grid on;


